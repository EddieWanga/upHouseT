import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDIcEUCeq2axlMMYoMBKOkieUkT076v2w8",
            authDomain: "uphomes-ca381.firebaseapp.com",
            projectId: "uphomes-ca381",
            storageBucket: "uphomes-ca381.appspot.com",
            messagingSenderId: "214412197619",
            appId: "1:214412197619:web:37739908edaba30d474186"));
  } else {
    await Firebase.initializeApp();
  }
}
