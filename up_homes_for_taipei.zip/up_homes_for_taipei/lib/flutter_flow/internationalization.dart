import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'zh_Hant'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? zh_HantText = '',
  }) =>
      [enText, zh_HantText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // login
  {
    'el9nybbw': {
      'en': 'Welcome Back,',
      'zh_Hant': '',
    },
    '1mdy0w41': {
      'en': 'Email Address',
      'zh_Hant': '',
    },
    '1x6mg4n8': {
      'en': 'Enter your email here...',
      'zh_Hant': '',
    },
    '5t9cy5ok': {
      'en': 'Password',
      'zh_Hant': '',
    },
    '605wrgu7': {
      'en': 'Enter your email here...',
      'zh_Hant': '',
    },
    'diycub78': {
      'en': 'Forgot Password?',
      'zh_Hant': '',
    },
    '30k23jll': {
      'en': 'Login',
      'zh_Hant': '',
    },
    'pg5wmhbt': {
      'en': 'Don\'t have an account?',
      'zh_Hant': '',
    },
    'irj0xxfy': {
      'en': 'Create Account',
      'zh_Hant': '',
    },
    'y1123auf': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // createAccount
  {
    'u0skn0po': {
      'en': 'Get Started Below,',
      'zh_Hant': '',
    },
    'jookbpcc': {
      'en': 'Email Address',
      'zh_Hant': '',
    },
    'kgz9fxkm': {
      'en': 'Enter your email here...',
      'zh_Hant': '',
    },
    'vtyy5ccl': {
      'en': 'Password',
      'zh_Hant': '',
    },
    'f78k3b4e': {
      'en': 'Enter your email here...',
      'zh_Hant': '',
    },
    'b5tg8slq': {
      'en': 'Create Account',
      'zh_Hant': '',
    },
    'i5ba6alv': {
      'en': 'Already have an account?',
      'zh_Hant': '',
    },
    'sl74ki1h': {
      'en': 'Login',
      'zh_Hant': '',
    },
    '4kwmi810': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // homePage_MAIN
  {
    'bxyclya9': {
      'en': 'Welcome!',
      'zh_Hant': '',
    },
    'slousz27': {
      'en': 'Find your Dream Space To Getaway',
      'zh_Hant': '',
    },
    'ag2gshwm': {
      'en': 'Address, city, state...',
      'zh_Hant': '',
    },
    'dq8spdb9': {
      'en': 'Search',
      'zh_Hant': '',
    },
    'idkiahqj': {
      'en': 'Rating',
      'zh_Hant': '',
    },
    'ihunemkf': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // propertyDetails
  {
    'wln8zoaq': {
      'en': 'Reviews',
      'zh_Hant': '',
    },
    'zhe10y8z': {
      'en': 'DESCRIPTION',
      'zh_Hant': '',
    },
    '9pa9lk6g': {
      'en': 'Amenities',
      'zh_Hant': '',
    },
    '7qwa67k8': {
      'en': 'What people are saying',
      'zh_Hant': '',
    },
    '1eq6k2sv': {
      'en': 'Josh Richardson',
      'zh_Hant': '',
    },
    'dvxboj50': {
      'en':
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...',
      'zh_Hant': '',
    },
    '5hv405cw': {
      'en': 'Josh Richardson',
      'zh_Hant': '',
    },
    '02vuggkm': {
      'en':
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...',
      'zh_Hant': '',
    },
    '4e7wx82r': {
      'en': '\$156',
      'zh_Hant': '',
    },
    'bfwq60s9': {
      'en': '+ taxes/fees',
      'zh_Hant': '',
    },
    'ng44tmur': {
      'en': 'per night',
      'zh_Hant': '',
    },
    'cp908qyu': {
      'en': 'Book Now',
      'zh_Hant': '',
    },
    'viygcg70': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // searchProperties
  {
    'oyp50cmy': {
      'en': 'Search',
      'zh_Hant': '',
    },
    'fh7m1uf7': {
      'en': 'Address, city, state...',
      'zh_Hant': '',
    },
    'd116ajlf': {
      'en': 'Search',
      'zh_Hant': '',
    },
    'hvtqsru5': {
      'en': 'Rating',
      'zh_Hant': '',
    },
    'sei3a9jo': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // myTrips
  {
    '856yfc15': {
      'en': 'Upcoming',
      'zh_Hant': '',
    },
    'lhbloe2k': {
      'en': ' - ',
      'zh_Hant': '',
    },
    'lt69tdts': {
      'en': 'Total',
      'zh_Hant': '',
    },
    '1oxvo4k9': {
      'en': 'Completed',
      'zh_Hant': '',
    },
    'x8yvz1t9': {
      'en': 'Cancelled',
      'zh_Hant': '',
    },
    'thyq0oeb': {
      'en': ' - ',
      'zh_Hant': '',
    },
    'i6jt90w7': {
      'en': 'Rate Trip',
      'zh_Hant': '',
    },
    'rkhkg3fa': {
      'en': 'My Trips',
      'zh_Hant': '',
    },
    'hcv6i0j3': {
      'en': 'My Trips',
      'zh_Hant': '',
    },
  },
  // tripDetails
  {
    '61ra0o41': {
      'en': 'Trip Details',
      'zh_Hant': '',
    },
    'tiv9ne93': {
      'en': 'Dates of trip',
      'zh_Hant': '',
    },
    'ejaztow5': {
      'en': ' - ',
      'zh_Hant': '',
    },
    '3os0lqpx': {
      'en': 'Destination',
      'zh_Hant': '',
    },
    '45wrx2ab': {
      'en': 'Price Breakdown',
      'zh_Hant': '',
    },
    '0fjid2lq': {
      'en': 'Base Price',
      'zh_Hant': '',
    },
    '2hk7v3ye': {
      'en': 'Taxes',
      'zh_Hant': '',
    },
    '8fyethjx': {
      'en': '\$24.20',
      'zh_Hant': '',
    },
    'xtyc0qde': {
      'en': 'Cleaning Fee',
      'zh_Hant': '',
    },
    'mhm6x3v4': {
      'en': '\$40.00',
      'zh_Hant': '',
    },
    'nfjpz8tb': {
      'en': 'Total',
      'zh_Hant': '',
    },
    'wgj8xeh1': {
      'en': 'Your trip has been completed!',
      'zh_Hant': '',
    },
    'i7b3w0hw': {
      'en': 'Review Trip',
      'zh_Hant': '',
    },
    '2ce2rtcb': {
      'en': 'Host Info',
      'zh_Hant': '',
    },
    'yxu8ld7x': {
      'en': 'Chat',
      'zh_Hant': '',
    },
    '4409l3wq': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // chatMain
  {
    '2x5vn9tn': {
      'en': 'All Chats',
      'zh_Hant': '',
    },
    '9ioxbrf8': {
      'en': 'Chats',
      'zh_Hant': '',
    },
  },
  // chatDetails
  {
    '3ty4iu3u': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // propertyReview
  {
    'jyh9b3z4': {
      'en': 'Reviews',
      'zh_Hant': '',
    },
    'zzsx95f4': {
      'en': '# of Ratings',
      'zh_Hant': '',
    },
    'smyhccdy': {
      'en': 'Avg. Rating',
      'zh_Hant': '',
    },
    '1d1sbmwn': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // bookNow
  {
    'q3vlqrph': {
      'en': 'Book Now',
      'zh_Hant': '',
    },
    '1kus32o3': {
      'en': 'Choose Dates',
      'zh_Hant': '',
    },
    'zszzyow0': {
      'en': 'Number of Guests',
      'zh_Hant': '',
    },
    'c9d8w9uj': {
      'en': 'Choose an Option',
      'zh_Hant': '',
    },
    'z08h3rzj': {
      'en': 'Breakfast',
      'zh_Hant': '',
    },
    '70driam6': {
      'en': 'No Breakfast',
      'zh_Hant': '',
    },
    'fww482b1': {
      'en': 'Hot Tub Access',
      'zh_Hant': '',
    },
    'se5i67os': {
      'en': 'No Access',
      'zh_Hant': '',
    },
    '3qdylf2q': {
      'en': 'Payment Information',
      'zh_Hant': '',
    },
    'vxi2w3e9': {
      'en': 'Base Price',
      'zh_Hant': '',
    },
    'tqizly4k': {
      'en': '\$156.00',
      'zh_Hant': '',
    },
    'ypine8bp': {
      'en': 'Taxes',
      'zh_Hant': '',
    },
    '13vda6g1': {
      'en': '\$24.20',
      'zh_Hant': '',
    },
    '9r8jj75q': {
      'en': 'Cleaning Fee',
      'zh_Hant': '',
    },
    'wuife6e7': {
      'en': '\$40.00',
      'zh_Hant': '',
    },
    '0cqrgh1u': {
      'en': 'Total',
      'zh_Hant': '',
    },
    'wn029uoa': {
      'en': '\$230.20',
      'zh_Hant': '',
    },
    'op6ztz25': {
      'en': 'Book Now',
      'zh_Hant': '',
    },
    'rjf4hsoh': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // profilePage
  {
    'edk862x9': {
      'en': 'Switch to Dark Mode',
      'zh_Hant': '',
    },
    '370i6n9q': {
      'en': 'Switch to Light Mode',
      'zh_Hant': '',
    },
    'd7h3ausq': {
      'en': 'Account Details',
      'zh_Hant': '',
    },
    'uwut69nl': {
      'en': 'Edit Profile',
      'zh_Hant': '',
    },
    'f9q2r8sn': {
      'en': 'Payment Information',
      'zh_Hant': '',
    },
    'kudf8osl': {
      'en': 'Change Password',
      'zh_Hant': '',
    },
    'uwnlxyr7': {
      'en': 'My Properties',
      'zh_Hant': '',
    },
    'mko8edva': {
      'en': 'My Bookings',
      'zh_Hant': '',
    },
    'stiei8lj': {
      'en': 'Log Out',
      'zh_Hant': '',
    },
    'qa192kdd': {
      'en': 'Add Property',
      'zh_Hant': '',
    },
    'odil2nzt': {
      'en': 'Profile',
      'zh_Hant': '',
    },
  },
  // paymentInfo
  {
    'mfj75xwv': {
      'en': 'Save Changes',
      'zh_Hant': '',
    },
    'zvjex17f': {
      'en': 'Payment Information',
      'zh_Hant': '',
    },
    'k1w3arlp': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // editProfile
  {
    't7n3qpzg': {
      'en': 'Edit Profile',
      'zh_Hant': '',
    },
    'nd7kzkm9': {
      'en': 'Change Photo',
      'zh_Hant': '',
    },
    'pg3ye9ud': {
      'en': 'Full Name',
      'zh_Hant': '',
    },
    'yv5w28yl': {
      'en': 'Your full name...',
      'zh_Hant': '',
    },
    'vac86i1u': {
      'en': 'Email Address',
      'zh_Hant': '',
    },
    'chax56bm': {
      'en': 'Your email..',
      'zh_Hant': '',
    },
    '9rrjun43': {
      'en': 'Bio',
      'zh_Hant': '',
    },
    'jsuf8til': {
      'en': 'A little about you...',
      'zh_Hant': '',
    },
    '1cqvqi48': {
      'en': 'Save Changes',
      'zh_Hant': '',
    },
    '2lh0zxr1': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // changePassword
  {
    'z6xowi6v': {
      'en': 'Email Address',
      'zh_Hant': '',
    },
    'opvk4tg9': {
      'en': 'Your email..',
      'zh_Hant': '',
    },
    'waohn1g1': {
      'en':
          'We will send you an email with a link to reset your password, please enter the email associated with your account above.',
      'zh_Hant': '',
    },
    'izvy3jps': {
      'en': 'Send Reset Link',
      'zh_Hant': '',
    },
    'lc13a9bm': {
      'en': 'Change Password',
      'zh_Hant': '',
    },
    '24keuvno': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // createProperty_1
  {
    'ip2e0s8q': {
      'en': 'PROPERTY NAME',
      'zh_Hant': '',
    },
    'a6mw7n8j': {
      'en': 'Something Catchy...',
      'zh_Hant': '',
    },
    '2rwjle6j': {
      'en': 'PROPERTY ADDRESS',
      'zh_Hant': '',
    },
    '4952tiev': {
      'en': '123 Disney way here…',
      'zh_Hant': '',
    },
    '7pp250s8': {
      'en': 'NEIGHBORHOOD',
      'zh_Hant': '',
    },
    'w1xqifcl': {
      'en': 'Neighborhood or city…',
      'zh_Hant': '',
    },
    'd8warq25': {
      'en': 'DESCRIPTION',
      'zh_Hant': '',
    },
    'wqmjc92x': {
      'en': 'Neighborhood or city…',
      'zh_Hant': '',
    },
    'tk8dw602': {
      'en': 'STEP',
      'zh_Hant': '',
    },
    'ai1x1mgz': {
      'en': '1/3',
      'zh_Hant': '',
    },
    '57mbtfcb': {
      'en': 'NEXT',
      'zh_Hant': '',
    },
    'bxugndwa': {
      'en': 'Create Property',
      'zh_Hant': '',
    },
    'ytm7o0df': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // HomePage_ALT
  {
    'dk7acpgs': {
      'en': 'Welcome!',
      'zh_Hant': '',
    },
    'wajw4a8o': {
      'en': 'Find your Dream Space',
      'zh_Hant': '',
    },
    'n5ukbd9q': {
      'en': 'Address, city, state...',
      'zh_Hant': '',
    },
    'apdoeahu': {
      'en': 'Search',
      'zh_Hant': '',
    },
    'b2jboehd': {
      'en': '4/5 reviews',
      'zh_Hant': '',
    },
    'a86opel4': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // createProperty_2
  {
    'cnin5vau': {
      'en': 'Create Property',
      'zh_Hant': '',
    },
    '1uo05knm': {
      'en': 'CHOOSE YOUR AMENITIES',
      'zh_Hant': '',
    },
    'fjct2rc1': {
      'en': 'Pool',
      'zh_Hant': '',
    },
    '3j5138d3': {
      'en': 'EV Car Charging',
      'zh_Hant': '',
    },
    'uzmecq3s': {
      'en': 'Extra Outlets',
      'zh_Hant': '',
    },
    '7tmd048x': {
      'en': 'Air Conditioning (AC)',
      'zh_Hant': '',
    },
    'shs0b248': {
      'en': 'Heating',
      'zh_Hant': '',
    },
    '3hetzyk0': {
      'en': 'Washer',
      'zh_Hant': '',
    },
    'jp4xiyq2': {
      'en': 'Dryer',
      'zh_Hant': '',
    },
    '0mnhubh5': {
      'en': 'Pet Friendly',
      'zh_Hant': '',
    },
    '2xppr4sb': {
      'en': 'Workout Facility',
      'zh_Hant': '',
    },
    'vonpmuxt': {
      'en': 'Hip',
      'zh_Hant': '',
    },
    'pcfs8djj': {
      'en': 'Night Life',
      'zh_Hant': '',
    },
    '3lldefzw': {
      'en': 'STEP',
      'zh_Hant': '',
    },
    '3rldizc1': {
      'en': '2/3',
      'zh_Hant': '',
    },
    'sri44ls9': {
      'en': 'NEXT',
      'zh_Hant': '',
    },
    'jdnmena4': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // createProperty_3
  {
    'of6sgipy': {
      'en': 'Create Property',
      'zh_Hant': '',
    },
    'ea53de4v': {
      'en': 'PRICE PER NIGHT',
      'zh_Hant': '',
    },
    'annvxjvf': {
      'en': '\$ Price',
      'zh_Hant': '',
    },
    '0rviqeio': {
      'en': 'MINIMUM NIGHT STAY',
      'zh_Hant': '',
    },
    'rq99uuzm': {
      'en': 'TAX RATE',
      'zh_Hant': '',
    },
    'r10tzc2s': {
      'en': '% Rate',
      'zh_Hant': '',
    },
    'eku9bvnz': {
      'en': 'CLEANING FEE',
      'zh_Hant': '',
    },
    'wrjiu7nn': {
      'en': '\$ Price',
      'zh_Hant': '',
    },
    'ckkx0oyz': {
      'en': 'Additional Notes',
      'zh_Hant': '',
    },
    'y3uf9y7r': {
      'en': 'Additional notes...',
      'zh_Hant': '',
    },
    'e5ih0a77': {
      'en': 'STEP',
      'zh_Hant': '',
    },
    '96nyg4y8': {
      'en': '3/3',
      'zh_Hant': '',
    },
    'zdiqyn29': {
      'en': 'PUBLISH',
      'zh_Hant': '',
    },
    '1pcocpnz': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // myProperties
  {
    'pjqhxy1a': {
      'en': 'Published',
      'zh_Hant': '',
    },
    'l5iu6tjk': {
      'en': 'Price Per Night',
      'zh_Hant': '',
    },
    'l6ya70lc': {
      'en': 'Drafts',
      'zh_Hant': '',
    },
    'ns36ifs0': {
      'en': 'Price Per Night',
      'zh_Hant': '',
    },
    'ltoc1k6h': {
      'en': 'My Properties',
      'zh_Hant': '',
    },
    'zdp01qqd': {
      'en': 'My Trips',
      'zh_Hant': '',
    },
  },
  // propertyDetails_Owner
  {
    'imm8th62': {
      'en': 'Reviews',
      'zh_Hant': '',
    },
    'ciohfys9': {
      'en': 'DESCRIPTION',
      'zh_Hant': '',
    },
    '82he6umj': {
      'en': 'Amenities',
      'zh_Hant': '',
    },
    'uof76r6q': {
      'en': 'What people are saying',
      'zh_Hant': '',
    },
    'd59gcc9z': {
      'en': 'Josh Richardson',
      'zh_Hant': '',
    },
    '2eswcyjl': {
      'en':
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...',
      'zh_Hant': '',
    },
    'in2uujj6': {
      'en': 'Josh Richardson',
      'zh_Hant': '',
    },
    'uoj0tni7': {
      'en':
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...',
      'zh_Hant': '',
    },
    'i0gmv6tj': {
      'en': '\$156',
      'zh_Hant': '',
    },
    'lzc5l9mw': {
      'en': '+ taxes/fees',
      'zh_Hant': '',
    },
    '7vtqb185': {
      'en': 'per night',
      'zh_Hant': '',
    },
    'l2bamfvx': {
      'en': 'Edit Property',
      'zh_Hant': '',
    },
    'xw67ojks': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // myBookings
  {
    'duh3ozyg': {
      'en': 'Upcoming ',
      'zh_Hant': '',
    },
    'xry1ibky': {
      'en': ' - ',
      'zh_Hant': '',
    },
    '05xr2v8f': {
      'en': 'Total',
      'zh_Hant': '',
    },
    '8cjs8pwz': {
      'en': 'Completed',
      'zh_Hant': '',
    },
    'mryiji4c': {
      'en': ' - ',
      'zh_Hant': '',
    },
    'nlxog2wi': {
      'en': 'Total',
      'zh_Hant': '',
    },
    '5hwjk3hx': {
      'en': 'My Bookings',
      'zh_Hant': '',
    },
    'u3r905ox': {
      'en': 'My Trips',
      'zh_Hant': '',
    },
  },
  // tripDetailsHOST
  {
    'qu992v1e': {
      'en': 'Trip Details',
      'zh_Hant': '',
    },
    'ljnq78v7': {
      'en': 'Dates of trip',
      'zh_Hant': '',
    },
    'rmqwswvr': {
      'en': ' - ',
      'zh_Hant': '',
    },
    '8f9mx3cq': {
      'en': 'Destination',
      'zh_Hant': '',
    },
    'q87ni8mj': {
      'en': 'Price Breakdown',
      'zh_Hant': '',
    },
    'kgeibcf7': {
      'en': 'Base Price',
      'zh_Hant': '',
    },
    '8rrowtkr': {
      'en': 'Taxes',
      'zh_Hant': '',
    },
    'tbaumlaj': {
      'en': '\$24.20',
      'zh_Hant': '',
    },
    'r9fyd1ap': {
      'en': 'Cleaning Fee',
      'zh_Hant': '',
    },
    'inu41pqk': {
      'en': '\$40.00',
      'zh_Hant': '',
    },
    'suamp5aq': {
      'en': 'Total',
      'zh_Hant': '',
    },
    's6vx33t6': {
      'en': 'Mark this trip as complete below.',
      'zh_Hant': '',
    },
    'ee66zutj': {
      'en': 'Mark as Complete',
      'zh_Hant': '',
    },
    '8435qcmh': {
      'en': 'Guest Info',
      'zh_Hant': '',
    },
    'e9d7z54z': {
      'en': 'Chat',
      'zh_Hant': '',
    },
    'hfr5cs22': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // editProperty_1
  {
    'u4ph1qhe': {
      'en': 'Edit Property',
      'zh_Hant': '',
    },
    'yjpppyb6': {
      'en': 'PROPERTY NAME',
      'zh_Hant': '',
    },
    'h67xytcr': {
      'en': 'Something Catchy...',
      'zh_Hant': '',
    },
    'wd5t0xss': {
      'en': 'PROPERTY ADDRESS',
      'zh_Hant': '',
    },
    'd01x482b': {
      'en': '123 Disney way here…',
      'zh_Hant': '',
    },
    'cu4ayepd': {
      'en': 'NEIGHBORHOOD',
      'zh_Hant': '',
    },
    'wphl4obw': {
      'en': 'Neighborhood or city…',
      'zh_Hant': '',
    },
    'dytqd1j2': {
      'en': 'DESCRIPTION',
      'zh_Hant': '',
    },
    'ta6hs3ej': {
      'en': 'Neighborhood or city…',
      'zh_Hant': '',
    },
    'slwvilvx': {
      'en': 'STEP',
      'zh_Hant': '',
    },
    'pt7v7md5': {
      'en': '1/3',
      'zh_Hant': '',
    },
    'bhe50dhh': {
      'en': 'NEXT',
      'zh_Hant': '',
    },
    'rinlni7i': {
      'en': 'We need to know the name of the place...',
      'zh_Hant': '',
    },
    'r3yu89bs': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // editProperty_2
  {
    '4kiem21e': {
      'en': 'Edit Property',
      'zh_Hant': '',
    },
    'bma8y5gi': {
      'en': 'CHOOSE YOUR AMENITIES',
      'zh_Hant': '',
    },
    '29iy6hlc': {
      'en': 'Pool',
      'zh_Hant': '',
    },
    '3ixldhnf': {
      'en': 'EV Car Charging',
      'zh_Hant': '',
    },
    '819llwkd': {
      'en': 'Extra Outlets',
      'zh_Hant': '',
    },
    'bmyouauj': {
      'en': 'Air Conditioning (AC)',
      'zh_Hant': '',
    },
    'wxep8v7p': {
      'en': 'Heating',
      'zh_Hant': '',
    },
    'ikhqrh2b': {
      'en': 'Washer',
      'zh_Hant': '',
    },
    'd34q0llz': {
      'en': 'Dryer',
      'zh_Hant': '',
    },
    'tnuxw35s': {
      'en': 'Pet Friendly',
      'zh_Hant': '',
    },
    'y12k0whr': {
      'en': 'Workout Facility',
      'zh_Hant': '',
    },
    'u5zyf7ds': {
      'en': 'Hip',
      'zh_Hant': '',
    },
    'yjsbk4mc': {
      'en': 'Night Life',
      'zh_Hant': '',
    },
    'c29s2p3d': {
      'en': 'STEP',
      'zh_Hant': '',
    },
    'qppvr5je': {
      'en': '2/3',
      'zh_Hant': '',
    },
    '14li8u82': {
      'en': 'NEXT',
      'zh_Hant': '',
    },
    'z7rulb2l': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // editProperty_3
  {
    'k07y00ea': {
      'en': 'Edit Property',
      'zh_Hant': '',
    },
    'b7szrkm0': {
      'en': 'PRICE PER NIGHT',
      'zh_Hant': '',
    },
    'ul8nru29': {
      'en': '\$ Price',
      'zh_Hant': '',
    },
    'bdx4hx0r': {
      'en': 'MINIMUM NIGHT STAY',
      'zh_Hant': '',
    },
    'e0hflq50': {
      'en': 'TAX RATE',
      'zh_Hant': '',
    },
    'g6qbhx53': {
      'en': '% Rate',
      'zh_Hant': '',
    },
    'ct0s7kvv': {
      'en': 'CLEANING FEE',
      'zh_Hant': '',
    },
    'xoimxvky': {
      'en': '\$ Price',
      'zh_Hant': '',
    },
    'h9pibzaf': {
      'en': 'Additional Notes',
      'zh_Hant': '',
    },
    'nnff4bh0': {
      'en': 'Additional notes...',
      'zh_Hant': '',
    },
    'ined7xrw': {
      'en': 'Listing is Live',
      'zh_Hant': '',
    },
    '5fyzduqc': {
      'en': 'Turn this on for guests to start booking your listing.',
      'zh_Hant': '',
    },
    '36xys7gb': {
      'en': 'STEP',
      'zh_Hant': '',
    },
    'noy1yrcn': {
      'en': '3/3',
      'zh_Hant': '',
    },
    'jnwfb8pe': {
      'en': 'Save Changes',
      'zh_Hant': '',
    },
    '2to8hz81': {
      'en': 'Home',
      'zh_Hant': '',
    },
  },
  // bottomSheet
  {
    'hgafcye0': {
      'en': 'Session Booked!',
      'zh_Hant': '',
    },
    'bvojlxxd': {
      'en': 'You have successfully booked a session on:',
      'zh_Hant': '',
    },
    'k451vfdq': {
      'en': 'Mon, Dec 11 - 2021',
      'zh_Hant': '',
    },
  },
  // total
  {
    '6adyifou': {
      'en': 'Order Total',
      'zh_Hant': '',
    },
    'cwmn30pq': {
      'en':
          'Your order total is a summary of all items in your order minus any fees and taxes associated with your purchase.',
      'zh_Hant': '',
    },
    'oqafb72v': {
      'en': 'Okay',
      'zh_Hant': '',
    },
  },
  // changePhoto
  {
    'd60mv1e3': {
      'en': 'Change Profile Photo',
      'zh_Hant': '',
    },
    'zhmcw5v3': {
      'en': 'Upload Photo',
      'zh_Hant': '',
    },
    'tcbek8jd': {
      'en': 'Save Photo',
      'zh_Hant': '',
    },
  },
  // reviewTrip
  {
    '0fs8jd47': {
      'en': 'Rate Your Trip',
      'zh_Hant': '',
    },
    'mobr6g2s': {
      'en': 'Let us know what you thought of the place below!',
      'zh_Hant': '',
    },
    'nyrrnibp': {
      'en': 'How would you rate it?',
      'zh_Hant': '',
    },
    'lo01krgs': {
      'en': 'Please leave a description of the place...',
      'zh_Hant': '',
    },
    'cw1xf1hd': {
      'en': 'Submit Review',
      'zh_Hant': '',
    },
  },
  // changeMainPhoto
  {
    'c2wq4rfo': {
      'en': 'Change Main Photo',
      'zh_Hant': '',
    },
    'p8366h95': {
      'en': 'Upload Photo',
      'zh_Hant': '',
    },
    '7vc1h0pb': {
      'en': 'Save Photo',
      'zh_Hant': '',
    },
  },
  // cancelTrip
  {
    'jvs9m5po': {
      'en': 'Cancel Trip',
      'zh_Hant': '',
    },
    'ngpl6duf': {
      'en':
          'If you want to cancel your tripl please leave a note below to send to the host.',
      'zh_Hant': '',
    },
    'rotvx1nc': {
      'en': 'Your reason for cancelling...',
      'zh_Hant': '',
    },
    'pq8xoygs': {
      'en': 'Yes, Cancel Trip',
      'zh_Hant': '',
    },
    '4sg8wdmh': {
      'en': 'Never Mind',
      'zh_Hant': '',
    },
  },
  // cancelTripHOST
  {
    'rnmib7ms': {
      'en': 'Cancel Trip',
      'zh_Hant': '',
    },
    'tsew64sa': {
      'en':
          'If you want to cancel your tripl please leave a note below to send to the host.',
      'zh_Hant': '',
    },
    '6x0mw02a': {
      'en': 'Your reason for cancelling...',
      'zh_Hant': '',
    },
    'uvko6hfo': {
      'en': 'Yes, Cancel Trip',
      'zh_Hant': '',
    },
    'p8im1zvs': {
      'en': 'Never Mind',
      'zh_Hant': '',
    },
  },
  // Miscellaneous
  {
    's9dfs37z': {
      'en': '',
      'zh_Hant': '',
    },
    'wr7mixm9': {
      'en': '',
      'zh_Hant': '',
    },
    '0omqrko1': {
      'en': '',
      'zh_Hant': '',
    },
    'blotw7sv': {
      'en': '',
      'zh_Hant': '',
    },
    'hfkjvekg': {
      'en': '',
      'zh_Hant': '',
    },
    'dipmetb0': {
      'en': '',
      'zh_Hant': '',
    },
    'tttlp389': {
      'en': '',
      'zh_Hant': '',
    },
    'iygac8yy': {
      'en': '',
      'zh_Hant': '',
    },
    'xpsyug56': {
      'en': '',
      'zh_Hant': '',
    },
    'iix10c45': {
      'en': '',
      'zh_Hant': '',
    },
    '241gv8yh': {
      'en': '',
      'zh_Hant': '',
    },
    'enwd0xs8': {
      'en': '',
      'zh_Hant': '',
    },
    'znqoj7qu': {
      'en': '',
      'zh_Hant': '',
    },
    '6v879cnr': {
      'en': '',
      'zh_Hant': '',
    },
    'cda5is7h': {
      'en': '',
      'zh_Hant': '',
    },
    'pjcx74wh': {
      'en': '',
      'zh_Hant': '',
    },
    'octjvxbe': {
      'en': '',
      'zh_Hant': '',
    },
    '2j1waupj': {
      'en': '',
      'zh_Hant': '',
    },
    'w3wz1rsy': {
      'en': '',
      'zh_Hant': '',
    },
    'zkylbhxz': {
      'en': '',
      'zh_Hant': '',
    },
    'w7yhmcr9': {
      'en': '',
      'zh_Hant': '',
    },
    'bz0uzf5w': {
      'en': '',
      'zh_Hant': '',
    },
    '35hgxvfi': {
      'en': '',
      'zh_Hant': '',
    },
  },
].reduce((a, b) => a..addAll(b));
